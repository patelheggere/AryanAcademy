package com.money.plan.budgetcalculator.model;

public class ItemModel {
    private String date;
}
